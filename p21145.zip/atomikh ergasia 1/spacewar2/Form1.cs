﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Media;

namespace Fighter_Jet_Shooting_Game_MOO_ICT
{
    public partial class Form1 : Form
    {

        bool goLeft, goRight, shooting, isGameOver;
        int score;
        int playerSpeed = 12;
        int enemySpeed;
        int bulletSpeed;
        int seconds;
        Random rnd = new Random();
        int[] scoreboard = new int[10];
        SoundPlayer s;

        void ScoreBoard(int x)
        {
            if (x > scoreboard[0])
            {
                scoreboard[0] = x;
                int temp;
                for (int i = 0; i < 9; i++)
                {
                    for(int j = 0; j < 10 - (1 + i); j++)
                    {
                        if (scoreboard[j] > scoreboard[j + 1])
                        {
                            temp = scoreboard[j+1];
                            scoreboard[j+1] = scoreboard[j];
                            scoreboard[j] = temp;   
                        }
                    }


                }
            }
        }
        void TimeLeft()
        {
            if (seconds > 0)
            {
                seconds -= 1;
                label1.Text = seconds + "seconds";
                   ;
            }
            else
            {
                gameOver();
            }
        }

        void SerializeScoreboard(int[] points)
        {
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("scorers.ser",
                FileMode.OpenOrCreate, FileAccess.Write);
            formatter.Serialize(stream, scoreboard);
            stream.Close();
        }
        int[] DeserializeScoreboard()
        {
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("scorers.ser", FileMode.Open, FileAccess.Read);
            scoreboard = (int[])formatter.Deserialize(stream);
            return scoreboard;
        }


        public Form1()
        {
            InitializeComponent();
            resetGame();
            scoreboard=DeserializeScoreboard();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            txtScore.Text = score.ToString();


            enemy1.Top += enemySpeed;
            enemy2.Top += enemySpeed;
            enemy3.Top += enemySpeed;

            if (blue.Bounds.IntersectsWith(enemy1.Bounds))
            {
                gameOver();
                   
            }

            if (blue.Bounds.IntersectsWith(enemy2.Bounds))
            {
                gameOver();

            }
            if (blue.Bounds.IntersectsWith(enemy3.Bounds))
            {
                gameOver();

            }




            // player movement logic starts

            if (goLeft == true && blue.Left > 0)
            {
                blue.Left -= playerSpeed;
            }
            if (goRight == true && blue.Left < 688)
            {
                blue.Left += playerSpeed;
            }
            // player movement logic ends

            if (shooting == true)
            {
                bulletSpeed = 20;
                lazer.Top -= bulletSpeed;
            }
            else
            {
                lazer.Left = -300;
                bulletSpeed = 0;
            }

            if (lazer.Top < -30)
            {
                shooting = false;
            }

            if (lazer.Bounds.IntersectsWith(enemy1.Bounds))
            {
                score += 1;
                enemy1.Top = -450;
                enemy1.Left = rnd.Next(20, 600);
                shooting = false;
            }
            if (lazer.Bounds.IntersectsWith(enemy2.Bounds))
            {
                score += 1;
                enemy2.Top = -650;
                enemy2.Left = rnd.Next(20, 600);
                shooting = false;
            }
            if (lazer.Bounds.IntersectsWith(enemy3.Bounds))
            {
                score += 1;
                enemy3.Top = -750;
                enemy3.Left = rnd.Next(20, 600);
                shooting = false;
            }

            if (score == 5)
            {
                enemySpeed = 10;
            }
            if (score == 10)
            {
                enemySpeed = 15;
            }


            ScoreBoard(score);
            Stars();

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                goRight = true;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            s = new SoundPlayer("lazer.wav");
        }

       void Stars()
        {
            foreach (Control x in this.Controls )
            {
                if(x is PictureBox && x.Tag == "star")
                {
                    x.Top += 10;
                    if (x.Top >366)
                    {
                        x.Top = 0;
                    }

                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            TimeLeft();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string show = string.Join(Environment.NewLine, scoreboard);
            MessageBox.Show(show);  
        }

        private void topScoresToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                goRight = false;
            }
            if (e.KeyCode == Keys.Space && shooting == false)
            {
                shooting = true;

                lazer.Top = blue.Top - 30;
                lazer.Left = blue.Left + (blue.Width / 2);
                s.Play();

            }
            if (e.KeyCode == Keys.Enter && isGameOver == true)
            {
                resetGame();
            }


        }
        private void resetGame()
        {
            timer1.Start();
            timer1.Start();
            enemySpeed = 6;


            enemy1.Left = rnd.Next(20, 500);
            enemy2.Left = rnd.Next(20, 500);
            enemy3.Left = rnd.Next(20, 500);

            enemy1.Top = rnd.Next(0, 100) * -1;
            enemy2.Top = rnd.Next(0, 200) * -1;
            enemy3.Top = rnd.Next(0, 300) * -1;

            score = 0;
            bulletSpeed = 0;
            lazer.Left = -300;
            shooting = false;
            seconds = 60;


            txtScore.Text = score.ToString();

        }

        private void gameOver()
        {
            isGameOver = true;
            timer1.Stop();
            timer2.Stop();
            txtScore.Text += Environment.NewLine + "Game Over!!" + Environment.NewLine + "Press Enter to try again.";
            SerializeScoreboard(scoreboard);
            
        }
    }
}

